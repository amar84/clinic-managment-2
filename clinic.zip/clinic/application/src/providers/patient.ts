import { Injectable } from '@angular/core';
import { map, filter, find, switchMap, tap, catchError, mergeMap } from 'rxjs/operators';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class patient {
  httpOptions = {
  headers: new HttpHeaders({

    'Content-Type':  'application/x-www-form-urlencoded'
  })
};

baseUrl="http://localhost:3000/";

    data: any;

    constructor(private http:HttpClient) {

    }
    // getpatient() {
    //     if (this.data) {
    //         return Promise.resolve(this.data);
    //     }
    //     return new Promise(resolve => {
    //         this.http.get('http://localhost:8080/api/patient')
    //         .map(res => res.json())
    //         .subscribe(data => {
    //             this.data = data;
    //             resolve(this.data)
    //         });
    //     });
    // }
    // createpatient(patient){

    //     let header = new Headers();
    //     header.append('Content-Type', 'application/json');
    //     this.http.post('http://localhost:8080/api/reviews', JSON.stringify(patient), {headers: headers})
    //     .subscribe(res => {
    //         console.log(res.json());
    //     });

    //     }
    //     deletepatient(id){
    //     this.http.delete('http://localhost:8080/api/patient' + id).subscribe((res) =>{
    //         console.log(res.json());
    //     })
    //     }

    login(body){
      console.log("service userid", body);
    return this.http.post<any>(`${this.baseUrl}users/authenticate`, body, this.httpOptions);
    }
    }

