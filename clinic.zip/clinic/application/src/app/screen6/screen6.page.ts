import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {RouterModule} from '@angular/router'
// import {patient} from '../../providers/patient';
import { UserService } from './../user.service'


@Component({
  selector: 'app-screen6',
  templateUrl: './screen6.page.html',
  styleUrls: ['./screen6.page.scss'],
})
export class Screen6Page implements OnInit {
data: any;

 constructor( private router: Router ,private user: UserService) {}
   viewPatientRecord(){
     
     this.user.viewPatientRecord().subscribe(data=>{
      console.log('view patient true', data);
      this.data= data;
      // this.router.navigate(['screen1']);
     }, (err) => {
     alert("something Wrong")
    })

   }

  ngOnInit() {
    this.viewPatientRecord();
  }

}
