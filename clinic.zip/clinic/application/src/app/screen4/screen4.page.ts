import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {RouterModule} from '@angular/router'
// import {patient} from '../../providers/patient';
import { UserService } from './../user.service'

@Component({
  selector: 'app-screen4',
  templateUrl: './screen4.page.html',
  styleUrls: ['./screen4.page.scss'],
})
export class Screen4Page implements OnInit {
  data: any;

   constructor( private router: Router ,private user: UserService) {}

  viewPatient(){
     
     this.user.viewPatient().subscribe(data=>{
      console.log('view patient true', data);
      this.data= data;
      // this.router.navigate(['screen1']);
     }, (err) => {
     alert("something Wrong")
    })

   }

  ngOnInit() {
    this.viewPatient();
  }

}
