import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-screen7',
  templateUrl: './screen7.page.html',
  styleUrls: ['./screen7.page.scss'],
})
export class Screen7Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
