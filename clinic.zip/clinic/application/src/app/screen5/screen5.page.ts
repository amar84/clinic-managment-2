import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {RouterModule} from '@angular/router'
// import {patient} from '../../providers/patient';
import { UserService } from './../user.service'

@Component({
  selector: 'app-screen5',
  templateUrl: './screen5.page.html',
  styleUrls: ['./screen5.page.scss'],
})
export class Screen5Page implements OnInit {

 name :any;
 date :any;
bloodPresure : any;
bloodGroup :any;
heartRate :any;
temp :any;
department : any;
doctor :any;
critical :any;

   constructor( private router: Router ,private user: UserService) {}

 addPatientRecord(){
     let body = {
      "name":this.name,
      "date":this.date,
      "bloodPresure":this.bloodPresure,
      "bloodGroup": this.bloodGroup,
      "heartRate":this.heartRate,
      "temp":this.temp,
      "department":this.department,
      "doctor": this.doctor,
      "critical":this.critical
     }
     console.log('add patient record', body);

     this.user.addPatientRecord(body).subscribe(data=>{
       if(data.msg == "Patient Record added Successfully"){

      
      console.log('add patient record true', data);
      this.router.navigate(['screen1']);
       }
       else{
         alert("something wrong")
       }
     }, (err) => {
     alert("something Wrong")
    })

   }

  ngOnInit() {
  }

}
