// import { patient } from './../../providers/patient';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {RouterModule} from '@angular/router'
// import {patient} from '../../providers/patient';
import { UserService } from './../user.service'


@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {

    username: any;
    password: any;

  constructor( private router: Router ,private user: UserService) {}

  ngOnInit(){

  }
   async login(){
     let body = {
      "username": this.username,
      "password": this.password
     }
     console.log('loginData user', this.username);

     this.user.login(body).subscribe(data=>{

      console.log('loginData true', data);
      this.router.navigate(['screen1']);


     }, (err) => {
     alert("something Wrong")
    })

   }

  toScreen1() {
    this.router.navigate(['screen1']);
  }

  toregister(){
    this.router.navigate(['register'])
  }
}
