import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-screen1',
  templateUrl: './screen1.page.html',
  styleUrls: ['./screen1.page.scss'],
})
export class Screen1Page implements OnInit {

  constructor(private router: Router) { }

  toScreen2() {
    this.router.navigate(['screen2']);
  }

  toScreen3() {
    this.router.navigate(['screen3']);
  }
  
  toScreen4() {
    this.router.navigate(['screen4']);
  }

  toScreen5() {
    this.router.navigate(['screen5']);
  }

  toScreen6() {
    this.router.navigate(['screen6']);
  }

  toScreen7() {
    this.router.navigate(['screen7']);
  }

  ngOnInit() {
  }
  

}
