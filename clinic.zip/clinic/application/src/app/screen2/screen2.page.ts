import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {RouterModule} from '@angular/router'
// import {patient} from '../../providers/patient';
import { UserService } from './../user.service'

@Component({
  selector: 'app-screen2',
  templateUrl: './screen2.page.html',
  styleUrls: ['./screen2.page.scss'],
})
export class Screen2Page implements OnInit {
name :any;
contact : any;
address :any;
email :any;
date :any;
   constructor( private router: Router ,private user: UserService) {}

  ngOnInit() {
  }
    addPatient(){
     let body = {
      "name":this.name,
      "contact":this.contact,
      "address":this.address,
      "email": this.email,
      "date":this.date
     }
     console.log('loginData user', body);

     this.user.addPatient(body).subscribe(data=>{
      console.log('add patient true', data);
      this.router.navigate(['screen1']);
     }, (err) => {
     alert("something Wrong")
    })

   }
   onClick(){
     
   }
}
