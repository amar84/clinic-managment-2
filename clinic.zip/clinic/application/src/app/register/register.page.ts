import { Component, OnInit } from '@angular/core';
// import { AngularFireAuth} from '@angular/fire/auth'
import { Router } from '@angular/router'

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {

  username: string = ""
  password: string = ""
  cpassword: string = ""

  constructor(private route: Router) { }

  ngOnInit() {
  }

 async register(){
    const {username, password, cpassword} = this

    this.route.navigate(['home'])

    if (password !== cpassword) {
      return console.error("Password dosn't match ")
    }
    // try {
    //   const res = await this.afAuth.auth.createUserWithEmailAndPassword(username + '@codedamn')
    //   console.log(res)
    // } catch(error) {
    //   console.dir(error)
    // }
  }
  tohome(){
    this.route.navigate(['home'])
  }

}
