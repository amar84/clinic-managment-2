const config = {
    apiKey: "AIzaSyDTj1NDJg3GEEytvq7y28jgK3G4e40Sg0s",
    authDomain: "clinicaldata-84.firebaseapp.com",
    projectId: "clinicaldata-84",
    storageBucket: "clinicaldata-84.appspot.com",
    messagingSenderId: "1069662686729",
    appId: "1:1069662686729:web:774b03da37de3bb49e72d8",
    measurementId: "G-GD6FP4D768"
}

export default config