import { Injectable } from '@angular/core'
import { map, filter, find, switchMap, tap, catchError, mergeMap } from 'rxjs/operators';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';


interface user {
	username: string,
	uid: string
}

@Injectable()
export class UserService {
  httpOptions = {
    headers: new HttpHeaders({

      'Content-Type':  'application/json'
    })
  };

  baseUrl="http://localhost:3000/";

      data: any;

      constructor(private http:HttpClient) {

      }

      login(body){
        console.log("service userid", body);
      return this.http.post<any>(`${this.baseUrl}users/authenticate`, body, this.httpOptions);
      }

      addPatient(body){
        console.log("service userid", body);
      return this.http.post<any>(`${this.baseUrl}patient/addPatient`, body, this.httpOptions);
      }

      viewPatient(){
      return this.http.get(`${this.baseUrl}patient/viewPatient`, this.httpOptions);
      }

       addPatientRecord(body){
        console.log("service userid", body);
      return this.http.post<any>(`${this.baseUrl}record/addPatientRecord`, body, this.httpOptions);
      }

      viewPatientRecord(){
      return this.http.get(`${this.baseUrl}record/viewPatientRecord`, this.httpOptions);
      }


	// setUser(user: user) {
	// 	this.user = user
	// }

	// getUsername(): string {
	// 	return this.user.username
	// }

	// reAuth(username: string, password: string) {
	// 	// return this.afAuth.auth.currentUser.updateEmail(username + '@something.com' + password)
	// }

	// updatePassword(newpassword: string) {
	// 	// return this.afAuth.auth.currentUser.updatePassword(newpassword)
	// }

	// updateEmail(newemail: string) {
	// 	// return this.afAuth.auth.currentUser.updateEmail(newemail + '@something.com')
	// }

	// async isAuthenticated() {
	// 	if(this.user) return true

	// 	// const user = await this.afAuth.authState.pipe(first()).toPromise()

	// 	// if(user) {
	// 	// 	this.setUser({
	// 	// 		username: user.email.split('@')[0],
	// 	// 		uid: user.uid
	// 	// 	})

	// 	// 	return true
	// 	// }
	// 	// return false
	// }

	// getUID(): string {
	// 	return this.user.uid
	// }
}
