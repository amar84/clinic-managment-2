module.exports = {
    database:'mongodb://localhost/meanauth2',
    secret:'yoursecret'
}