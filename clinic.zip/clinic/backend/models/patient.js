const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const config = require('../config/database');

//user schema
const Schema = mongoose.Schema({
    name:{ type: String,required:true},
    contact:{ type: Number,required:true},
    address:{ type: String,required:true},
    email:{type:String ,required:true},
    date:{type:String,required:true}

});
const Patient = module.exports = mongoose.model('Patient',Schema);








