const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const config = require('../config/database');

//user schema
const Schema = mongoose.Schema({
    name:{ type: String,required:true},
    date:{type:String,required:true},
    bloodPresure:{ type: String,required:true},
    bloodGroup:{ type: String,required:true},
    heartRate:{ type: String,required:true},
    temp:{ type: String,required:true},
    department:{type:String,required:true},
    doctor:{type:String,required:true},
    critical:{type:String,required:true},
    

});
const PatientRecord = module.exports = mongoose.model('PatientRecord',Schema);








