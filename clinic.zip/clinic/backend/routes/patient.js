const express = require('express');
const router = express.Router();
const passport = require('passport');
const jwt = require('jsonwebtoken');
const config = require('../config/database');
const Patient = require('../models/patient');
//register
router.post('/addPatient',(req,res,next)=>{
  let newPatient = new Patient({
        name:req.body.name,
        contact: req.body.contact,
        address: req.body.address,
        email:req.body.email,
       
        date:req.body.date
  });
  newPatient.save((err, contact) => {
    if (err) {
      res.json(err);
    } else {
      res.json({ msg: "Patient added Successfully" });
    }
  });

//   Patient.addPatient(newPatient,(err,patient)=>{
//     if(err){
//         res.json({success:false,msg:'Failed to register patient'});
//     }else{
//         res.json({success:true,msg:'patient registered'});
//     }
//   });
});
//authenticate
// router.post('/authenticate',(req,res,next)=>{
//     const username = req.body.username;
//     const password = req.body.password;

//     User.getUserByUsername(username,(err,user)=>{
//         if(err) throw err;
//         if(!user){
//             return res.json({success:false,msg:'user not found'});
//         }
//         User.comparePassword(password,user.password,(err,isMatch)=>{
//         //this is how programmer dubeg things
//             console.log(password,user.password,isMatch);
//             if(err) throw err;
//             if(isMatch){
//                 const token = jwt.sign({data: user},config.secret,{
//                     expiresIn:604800  //1 week
//                 });

//                 res.json({
//                     success:true,
//                    // token:'Bearer '+token,
//                    token: 'Bearer '+token,
//                     user:{
//                         id:user._id,
//                         name:user.name,
//                         username:user.username,
//                         email:user.email
//                     }
//                 });
//             }else{ 
//                 return res.json({success:false,msg:'wrong password'});
//             }
//         });
//     });
// });
//profile
// router.get('/viewPatient',passport.authenticate('jwt',{session:false}),(req,res,next)=>{
//     res.json({user:req.user});
// });

router.get("/viewPatient", (req, res, next) => {
    Patient.find(function(err, patient) {
      res.json(patient);
      console.log("zzzzzzzzzzz");
    });
  });



module.exports = router;